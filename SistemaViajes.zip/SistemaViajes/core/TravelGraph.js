import { Conexion } from '../models/Conexion.js';
import { Transporte } from '../models/Transporte.js';

export class TravelGraph {
    constructor() {
        this.adjList = new Map();
    }

    addNode(ciudad) {
        if (!this.adjList.has(ciudad)) this.adjList.set(ciudad, []);
    }

    addEdge(origen, destino, transportesData) {
        this.addNode(origen);
        this.addNode(destino);
        const listaTransportes = transportesData.map(t => 
            new Transporte(t.tipo, t.costo, t.tiempo, t.disponibilidad)
        );
        const conexion = new Conexion(destino, listaTransportes);
        this.adjList.get(origen).push(conexion);
    }

    construirDesdeDatos(data) {
        this.adjList.clear();
        if (data.ciudades) data.ciudades.forEach(c => this.addNode(c));
        if (data.conexiones) {
            data.conexiones.forEach(conn => {
                this.addEdge(conn.origen, conn.destino, conn.transportes);
            });
        }
    }

    /**
     * Calcula una ruta compleja pasando por múltiples ciudades
     */
    calcularRutaCompleja(listaCiudades, modo, criterio, filtros, tiemposEstancia) {
        let secuenciaCiudades = [...listaCiudades];

        // 1. Si es modo LIBRE, optimizar el orden (Heurística TSP: Vecino más cercano)
        if (modo === 'libre') {
            secuenciaCiudades = this.optimizarOrden(listaCiudades, criterio, filtros);
        }

        // 2. Calcular ruta tramo a tramo
        const rutaCompleta = [];
        let costoTotal = 0;
        let tiempoTotal = 0;
        let tiempoEstanciaTotal = 0;

        for (let i = 0; i < secuenciaCiudades.length - 1; i++) {
            const origen = secuenciaCiudades[i];
            const destino = secuenciaCiudades[i+1];

            // Ejecutar Dijkstra para este tramo
            const resultadoTramo = this.dijkstra(origen, destino, criterio, filtros);

            if (!resultadoTramo) return null; // Camino roto

            // Agregar tramos al resultado global
            resultadoTramo.rutaCompleta.forEach(paso => {
                // Agregar el tiempo de estancia si corresponde al destino del paso
                // Ojo: Dijkstra puede devolver múltiples pasos intermedios (A->B->C) para ir de A a C.
                // Aquí simplificamos: la estancia se suma al llegar al destino final del tramo principal.
                let estancia = 0;
                if (paso.destino === destino) {
                    estancia = tiemposEstancia[destino] || 0;
                }
                
                rutaCompleta.push({
                    ...paso,
                    tiempoEstanciaDestino: estancia
                });
            });

            costoTotal += resultadoTramo.costoTotal;
            tiempoTotal += resultadoTramo.tiempoTotal + (tiemposEstancia[destino] || 0);
            tiempoEstanciaTotal += (tiemposEstancia[destino] || 0);
        }

        // Sumar estancia en la ciudad de origen (opcional, generalmente no se cuenta, pero por si acaso)
        const estanciaOrigen = tiemposEstancia[secuenciaCiudades[0]] || 0;
        tiempoTotal += estanciaOrigen;
        tiempoEstanciaTotal += estanciaOrigen;

        return { rutaCompleta, costoTotal, tiempoTotal, tiempoEstanciaTotal };
    }

    /**
     * Heurística TSP: Vecino más cercano
     */
    /**
     * Encuentra la mejor secuencia probando todas las combinaciones posibles.
     */
    optimizarOrden(ciudades, criterio, filtros) {
        const origen = ciudades[0]; // Asumimos que la primera es fija (Origen)
        const destinos = ciudades.slice(1); // El resto se pueden reordenar

        // 1. Generar todas las permutaciones de los destinos
        const permutaciones = this.generarPermutaciones(destinos);
        
        let mejorOrden = null;
        let menorCostoGlobal = Infinity;

        console.log(`🧮 Analizando ${permutaciones.length} combinaciones posibles...`);

        // 2. Probar cada permutación
        for (let perm of permutaciones) {
            const secuenciaPrueba = [origen, ...perm];
            let costoAcumulado = 0;
            let esValida = true;

            // Calcular costo de esta secuencia completa
            for (let i = 0; i < secuenciaPrueba.length - 1; i++) {
                const tramo = this.dijkstra(secuenciaPrueba[i], secuenciaPrueba[i+1], criterio, filtros);
                
                if (!tramo) {
                    esValida = false;
                    break; // Ruta rota, descartar esta combinación
                }

                // Sumar costo según criterio
                if (criterio === 'costo') costoAcumulado += tramo.costoTotal;
                else if (criterio === 'tiempo') costoAcumulado += tramo.tiempoTotal;
                else costoAcumulado += tramo.costoTotal + (tramo.tiempoTotal * 20);
            }

            // Si la ruta conecta todo y es más barata que la anterior, la guardamos
            if (esValida && costoAcumulado < menorCostoGlobal) {
                menorCostoGlobal = costoAcumulado;
                mejorOrden = secuenciaPrueba;
            }
        }

        // Si encontramos una ruta válida, la devolvemos. Si no, devolvemos la original (aunque falle).
        return mejorOrden || ciudades;
    }

    /**
     * Función auxiliar recursiva para generar permutaciones
     * Entrada: [A, B, C] -> Salida: [[A,B,C], [A,C,B], [B,A,C]...]
     */
    generarPermutaciones(arreglo) {
        if (arreglo.length === 0) return [[]];
        const primera = arreglo[0];
        const resto = arreglo.slice(1);
        const permsSinPrimera = this.generarPermutaciones(resto);
        const todasLasPerms = [];

        permsSinPrimera.forEach((perm) => {
            for (let i = 0; i <= perm.length; i++) {
                const permConPrimera = [...perm.slice(0, i), primera, ...perm.slice(i)];
                todasLasPerms.push(permConPrimera);
            }
        });
        return todasLasPerms;
    }

    /**
     * Algoritmo de Dijkstra mejorado
     */
    dijkstra(inicio, fin, criterio, filtros = []) {
        const distancias = {};
        const predecesores = {};
        const cola = [];

        for (let ciudad of this.adjList.keys()) {
            distancias[ciudad] = Infinity;
            predecesores[ciudad] = null;
        }

        distancias[inicio] = 0;
        cola.push({ ciudad: inicio, pesoAcumulado: 0 });

        while (cola.length > 0) {
            cola.sort((a, b) => a.pesoAcumulado - b.pesoAcumulado);
            const actual = cola.shift();
            const ciudadActual = actual.ciudad;

            if (actual.pesoAcumulado > distancias[ciudadActual]) continue;
            if (ciudadActual === fin) break;

            const conexiones = this.adjList.get(ciudadActual);
            if (!conexiones) continue;

            for (let conexion of conexiones) {
                const vecino = conexion.ciudadDestino;

                for (let transporte of conexion.transportes) {
                    if (filtros.includes(transporte.tipo) || !transporte.disponibilidad) continue;

                    // --- CÁLCULO DEL PESO (AQUÍ ESTÁ LA MAGIA DEL CRITERIO) ---
                    let pesoExtra = 0;
                    if (criterio === 'costo') {
                        pesoExtra = transporte.costo;
                    } else if (criterio === 'tiempo') {
                        pesoExtra = transporte.tiempo;
                    } else if (criterio === 'equilibrado') {
                        // Fórmula: Costo + (Tiempo * ValorHora). Asumimos 1h = $20
                        pesoExtra = transporte.costo + (transporte.tiempo * 20);
                    }

                    const nuevaDistancia = distancias[ciudadActual] + pesoExtra;

                    if (nuevaDistancia < distancias[vecino]) {
                        distancias[vecino] = nuevaDistancia;
                        predecesores[vecino] = { 
                            ciudadAnterior: ciudadActual, 
                            transporteUsado: transporte 
                        };
                        cola.push({ ciudad: vecino, pesoAcumulado: nuevaDistancia });
                    }
                }
            }
        }

        return this.reconstruirRuta(predecesores, inicio, fin);
    }

    reconstruirRuta(predecesores, inicio, fin) {
        if (!predecesores[fin]) return null;
        
        const ruta = [];
        let actual = fin;
        let costoTotal = 0;
        let tiempoTotal = 0;

        while (actual !== inicio) {
            const paso = predecesores[actual];
            ruta.unshift({
                origen: paso.ciudadAnterior,
                destino: actual,
                transporte: paso.transporteUsado
            });
            costoTotal += paso.transporteUsado.costo;
            tiempoTotal += paso.transporteUsado.tiempo;
            actual = paso.ciudadAnterior;
        }

        return { rutaCompleta: ruta, costoTotal, tiempoTotal };
    }
}
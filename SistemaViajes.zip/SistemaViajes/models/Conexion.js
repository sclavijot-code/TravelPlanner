export class Conexion {
    /**
     * @param {string} ciudadDestino - Nombre de la ciudad a la que se viaja
     * @param {Array} transportes - Lista de objetos Transporte
     */
    constructor(ciudadDestino, transportes) {
        this.ciudadDestino = ciudadDestino;
        this.transportes = transportes || [];
    }
}
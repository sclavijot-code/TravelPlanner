export class Transporte {
    /**
     * @param {string} tipo - Tipo de transporte (avion, tren, bus)
     * @param {number} costo - Costo del viaje
     * @param {number} tiempo - Duración en horas
     * @param {boolean} disponibilidad - Si está disponible o cancelado
     */
    constructor(tipo, costo, tiempo, disponibilidad = true) {
        this.tipo = tipo;
        this.costo = costo;
        this.tiempo = tiempo;
        this.disponibilidad = disponibilidad;
    }
}
import { TravelGraph } from './core/TravelGraph.js';
import { GraphRenderer } from './ui/GraphRenderer.js';
import { PDFExporter } from './ui/PDFExporter.js';

// --- CONFIGURACIÓN DEL MAPA REAL (Leaflet) ---
class RealMapController {
    constructor(containerId) {
        // Coordenadas centrales aproximadas de cada continente
        this.coords = {
            europe: [54.5260, 15.2551],
            asia: [34.0479, 100.6197],
            na: [54.5260, -105.2551],  // Norteamérica
            sa: [-8.7832, -55.4915],   // Sudamérica
            africa: [-8.7832, 34.5085],
            oceania: [-22.7359, 140.0188],
            ca: [12.7690, -85.6024]    // Centroamérica
        };
        this.map = null;
        this.containerId = containerId;
    }

    inicializar() {
        // Crear el mapa (centrado en 0,0 por defecto)
        this.map = L.map(this.containerId).setView([20, 0], 2);
        
        // Cargar capas de OpenStreetMap (Gratis)
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors',
            maxZoom: 18,
            minZoom: 2
        }).addTo(this.map);
    }

    moverA(region) {
        if (!this.map) this.inicializar();
        
        const destino = this.coords[region] || [20, 0];
        // Animación de vuelo suave
        this.map.flyTo(destino, 3, {
            animate: true,
            duration: 2 // Segundos
        });
    }
}

// --- ESTADO ---
const appState = {
    grafo: new TravelGraph(),
    renderer: new GraphRenderer('network-map'),
    realMap: new RealMapController('real-map-container'), // Instancia del mapa real
    ciudadesSeleccionadas: [],
    modoViaje: 'fijo',
    continenteActual: null,
    ultimoResultado: null 
};

// --- ELEMENTOS DOM ---
const elements = {
    stepContinent: document.getElementById('step-continent'),
    introScreen: document.getElementById('intro-screen'),
    appInterface: document.getElementById('app-interface'),
    cityDropdown: document.getElementById('city-dropdown'),
    selectedList: document.getElementById('selected-cities-list'),
    statusMsg: document.getElementById('status-msg'),
    resultsSection: document.getElementById('results-section'),
    staysContainer: document.getElementById('stays-container'),
    rutaResumen: document.getElementById('ruta-resumen'),
    rutaDetalles: document.getElementById('ruta-detalles'),
    btnNext: document.getElementById('btn-goto-filters'),
    regionBadge: document.getElementById('region-badge'),
    
    // Contenedores de pasos
    stepCities: document.getElementById('step-cities'),
    stepFilters: document.getElementById('step-filters')
};

// --- 1. CARGA DE CONTINENTE ---
document.querySelectorAll('.card-continent').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const file = e.currentTarget.getAttribute('data-file');
        cargarContinente(file);
    });
});

async function cargarContinente(file) {
    try {
        elements.statusMsg.textContent = "Cargando mundo...";
        const response = await fetch(`./data/${file}.json`);
        if (!response.ok) throw new Error("Archivo JSON no encontrado");
        
        const data = await response.json();
        appState.grafo.construirDesdeDatos(data);
        appState.continenteActual = file;

        // UI Updates
        elements.introScreen.classList.add('hidden');
        elements.appInterface.classList.remove('hidden');
        elements.regionBadge.textContent = file.toUpperCase();
        
        llenarDropdown();
        appState.renderer.renderizar(appState.grafo);
        
        // Mover el mapa real al continente
        appState.realMap.moverA(file);

        // Resetear interfaz interna
        appState.ciudadesSeleccionadas = [];
        renderizarListaCiudades();
        elements.stepFilters.classList.add('hidden');
        elements.stepCities.classList.remove('hidden');
        elements.resultsSection.classList.add('hidden');

    } catch (error) {
        console.error(error);
        elements.statusMsg.textContent = "Error: " + error.message;
        setTimeout(() => elements.statusMsg.textContent = "", 3000);
    }
}

// --- 2. GESTIÓN CIUDADES ---
function llenarDropdown() {
    elements.cityDropdown.innerHTML = '<option value="">-- Selecciona --</option>';
    for (let ciudad of appState.grafo.adjList.keys()) {
        const opt = document.createElement('option');
        opt.value = opt.textContent = ciudad;
        elements.cityDropdown.appendChild(opt);
    }
}

document.getElementById('btn-add-city').addEventListener('click', () => {
    const ciudad = elements.cityDropdown.value;
    if (ciudad && !appState.ciudadesSeleccionadas.includes(ciudad)) {
        appState.ciudadesSeleccionadas.push(ciudad);
        renderizarListaCiudades();
    }
});

function renderizarListaCiudades() {
    elements.selectedList.innerHTML = "";
    if(appState.ciudadesSeleccionadas.length === 0) {
         elements.selectedList.innerHTML = '<li class="empty-msg">Vacío</li>';
    }

    appState.ciudadesSeleccionadas.forEach((c, i) => {
        const li = document.createElement('li');
        li.innerHTML = `<span>${appState.modoViaje === 'fijo' ? i+1 : '•'} ${c}</span>`;
        
        const btn = document.createElement('button');
        btn.textContent = "X";
        btn.className = "btn-delete";
        btn.onclick = () => {
            appState.ciudadesSeleccionadas.splice(i, 1);
            renderizarListaCiudades();
        };
        li.appendChild(btn);
        elements.selectedList.appendChild(li);
    });
    elements.btnNext.disabled = appState.ciudadesSeleccionadas.length < 2;
}

// --- NAVEGACIÓN PASOS ---
elements.btnNext.addEventListener('click', () => {
    elements.stepCities.classList.add('hidden');
    elements.stepFilters.classList.remove('hidden');
    generarInputsEstancia();
});

document.getElementById('btn-back-cities').addEventListener('click', () => {
    elements.stepFilters.classList.add('hidden');
    elements.stepCities.classList.remove('hidden');
});

function generarInputsEstancia() {
    elements.staysContainer.innerHTML = "";
    appState.ciudadesSeleccionadas.forEach(c => {
        const div = document.createElement('div');
        div.innerHTML = `<label style="font-size:0.8rem;">${c}</label> <input type="number" min="0" value="0" data-city="${c}" class="stay-input">`;
        elements.staysContainer.appendChild(div);
    });
}

// --- CÁLCULO ---
document.getElementById('btn-calculate-final').addEventListener('click', () => {
    const criterio = document.querySelector('input[name="criterio"]:checked').value;
    const filtros = Array.from(document.querySelectorAll('.transport-filter:checked')).map(cb => cb.value);
    const tiempos = {};
    document.querySelectorAll('.stay-input').forEach(i => tiempos[i.dataset.city] = Number(i.value));
    const limCosto = Number(document.getElementById('limit-cost').value) || Infinity;
    const limTiempo = Number(document.getElementById('limit-time').value) || Infinity;

    const resultado = appState.grafo.calcularRutaCompleja(
        appState.ciudadesSeleccionadas,
        appState.modoViaje,
        criterio,
        filtros,
        tiempos
    );

    if (!resultado) {
        alert("No se encontró ruta con estos filtros.");
        return;
    }

    if (resultado.costoTotal > limCosto || resultado.tiempoTotal > limTiempo) {
        alert(`Límites excedidos.\nCosto: $${resultado.costoTotal}\nTiempo: ${resultado.tiempoTotal}h`);
        return;
    }

    appState.ultimoResultado = resultado;
    mostrarResultadosUI(resultado);
});

function mostrarResultadosUI(res) {
    elements.stepFilters.classList.add('hidden'); // Ocultar filtros para ver mapa mejor
    // Opcional: Podríamos volver a mostrar las ciudades si quisiéramos
    // elements.stepCities.classList.remove('hidden'); 

    elements.resultsSection.classList.remove('hidden');

    elements.rutaResumen.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <div>
                <span style="font-size: 1.1rem; color: var(--primary-color);">💰 <strong>$${res.costoTotal}</strong></span>
                <span style="margin: 0 5px; color:#ccc">|</span>
                <span style="font-size: 1.1rem; color: var(--primary-color);">⏱ <strong>${res.tiempoTotal}h</strong></span>
            </div>
            <small style="color:#666; font-size:0.8rem;">Estancia: ${res.tiempoEstanciaTotal}h</small>
        </div>
    `;

    elements.rutaDetalles.innerHTML = res.rutaCompleta.map((paso, i) => {
        let icono = '🚌';
        if (paso.transporte.tipo === 'avion') icono = '✈️';
        if (paso.transporte.tipo === 'tren') icono = '🚆';

        let html = `
        <li>
            <div style="flex: 1;">
                <strong>${i + 1}. ${paso.origen} ➝ ${paso.destino}</strong><br>
                <span class="badge ${paso.transporte.tipo}">${icono} ${paso.transporte.tipo.toUpperCase()}</span>
            </div>
            <div style="text-align: right;">
                <div style="font-weight: bold;">$${paso.transporte.costo}</div>
                <div style="font-size: 0.8rem; color: #666;">${paso.transporte.tiempo}h</div>
            </div>
        </li>`;

        if (paso.tiempoEstanciaDestino > 0) {
            html += `
            <li style="background-color: #fff8e1; border-left: 3px solid #ffc107;">
                <div style="flex: 1;">🏨 Estancia en ${paso.destino}</div>
                <div style="font-weight: bold; color: #d35400;">+${paso.tiempoEstanciaDestino}h</div>
            </li>`;
        }
        return html;
    }).join('');
}

// --- PDF ---
document.getElementById('btn-download-pdf').addEventListener('click', () => {
    if (appState.ultimoResultado) {
        PDFExporter.generarItinerario(appState.ultimoResultado, appState.continenteActual, appState.ciudadesSeleccionadas.length);
    }
});

// Reset
document.getElementById('btn-reset').addEventListener('click', () => location.reload());

// Listeners extra
document.querySelectorAll('input[name="trip-mode"]').forEach(r => {
    r.addEventListener('change', e => {
        appState.modoViaje = e.target.value;
        renderizarListaCiudades();
    });
});
// ui/GraphRenderer.js
export class GraphRenderer {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.network = null;
    }

    renderizar(grafo) {
        const nodos = [];
        const aristas = [];

        // Convertir datos del grafo a formato Vis.js
        for (let [ciudadOrigen, conexiones] of grafo.adjList) {
            nodos.push({ 
                id: ciudadOrigen, 
                label: ciudadOrigen, 
                shape: 'dot', 
                size: 20,
                color: { background: '#3498db', border: '#2980b9' },
                font: { size: 16, color: '#333', background: 'rgba(255,255,255,0.8)' }
            });

            conexiones.forEach(conn => {
                let iconos = conn.transportes.map(t => {
                    if(t.tipo === 'avion') return "✈️";
                    if(t.tipo === 'tren') return "🚆";
                    if(t.tipo === 'bus') return "🚌";
                    return "";
                }).join("");

                aristas.push({
                    from: ciudadOrigen,
                    to: conn.ciudadDestino,
                    label: iconos,
                    arrows: 'to',
                    color: { color: '#bdc3c7', highlight: '#3498db' },
                    length: 250
                });
            });
        }

        const data = {
            nodes: new vis.DataSet(nodos),
            edges: new vis.DataSet(aristas)
        };

        const options = {
            physics: {
                enabled: true,
                solver: 'repulsion',
                repulsion: { nodeDistance: 200, springLength: 300 },
                stabilization: { iterations: 1000 }
            },
            interaction: { hover: true, navigationButtons: true, zoomView: true },
            layout: { randomSeed: 2 } // Semilla para consistencia
        };

        if (this.network) {
            this.network.destroy(); // Limpiar memoria si ya existía uno
        }
        
        this.network = new vis.Network(this.container, data, options);
    }
}
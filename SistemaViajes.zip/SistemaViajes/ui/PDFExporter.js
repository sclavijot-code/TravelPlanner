// ui/PDFExporter.js
export class PDFExporter {
    static generarItinerario(rutaData, continente, ciudadesCount) {
        if (!window.jspdf) {
            console.error("Librería jsPDF no cargada");
            return;
        }

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        const colorPrimary = [44, 62, 80];
        const colorAccent = [52, 152, 219];
        const fecha = new Date().toLocaleDateString();

        // Encabezado
        doc.setFillColor(...colorPrimary);
        doc.rect(0, 0, 210, 40, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(22);
        doc.text("Plan de Viaje - TravelPlanner", 14, 20);
        doc.setFontSize(10);
        doc.text(`Generado el: ${fecha}`, 14, 30);

        // Info General
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(12);
        doc.text(`Región: ${continente.toUpperCase()}`, 14, 50);
        doc.text(`Ciudades a visitar: ${ciudadesCount}`, 14, 58);
        
        doc.setFontSize(14);
        doc.setTextColor(...colorAccent);
        doc.text(`Costo Total: $${rutaData.costoTotal} | Tiempo: ${rutaData.tiempoTotal}h`, 14, 70);

        // Tabla
        const filasTabla = rutaData.rutaCompleta.map((paso, index) => [
            index + 1,
            paso.origen,
            paso.destino,
            paso.transporte.tipo.toUpperCase(),
            `$${paso.transporte.costo}`,
            `${paso.transporte.tiempo}h`
        ]);

        doc.autoTable({
            startY: 80,
            head: [['#', 'Origen', 'Destino', 'Medio', 'Costo', 'Duración']],
            body: filasTabla,
            theme: 'grid',
            headStyles: { fillColor: colorAccent, textColor: 255 },
            alternateRowStyles: { fillColor: [240, 248, 255] }
        });

        // Footer
        const finalY = doc.lastAutoTable.finalY + 10;
        doc.setFontSize(10);
        doc.setTextColor(100);
        doc.text("Gracias por usar TravelPlanner.", 14, finalY);

        doc.save(`Itinerario_${continente}_${Date.now()}.pdf`);
    }
}